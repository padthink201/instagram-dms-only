# DMs — Instagram without the distractions (Android)

What works: messages, voice messages, sending photos, watching and posting stories,
opening reels/posts friends send you (likes, comments, sound).

What's blocked: the feed, the Reels tab, Explore, profiles, swiping to other reels,
sharing reels, creating posts/reels, and all notifications (the app has no
notification permission at all).

## Get the APK, option A: GitHub (nothing to install)
1. Create a **private** repo on github.com and upload everything in this folder
   (include the hidden `.github` folder).
2. Open the repo's **Actions** tab. The "Build APK" job runs on its own (~3–5 min).
3. Open the finished run → **Artifacts** → download `DMs-apk` (a zip with `app-debug.apk`).
4. Copy the APK to your phone, open it, allow "install unknown apps" when asked.

## Get the APK, option B: Android Studio
Open this folder in Android Studio → wait for Gradle sync → plug in your phone
(USB debugging on) → press Run ▶.

## After installing
- Log in once. Then **uninstall the real Instagram app**.
- If something you need gets blocked, a "Blocked: /…/" message appears for a few seconds.
  Add that path to `ALLOWED_PREFIXES` in `app/src/main/assets/dmonly.js` and rebuild.
- Rebuilt APKs install as updates (same signing key), so you stay logged in.

Keep the repo private: `app/debug.keystore` is the signing key.
